interface User {
    id: number;
    nome: string;
    usuario: string;
    senha: string;
}

export default User;